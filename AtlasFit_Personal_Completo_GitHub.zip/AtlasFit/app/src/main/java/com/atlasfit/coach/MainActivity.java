package com.atlasfit.coach;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.os.Build;
import android.content.pm.PackageManager;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {
  private WebView web;
  private SensorManager manager;
  private Sensor stepSensor;
  private SharedPreferences prefs;
  private float lastSensorValue = -1;
  private String currentDay;
  private String pendingText;
  @Override public void onCreate(Bundle b) { super.onCreate(b);
    prefs=getSharedPreferences("steps",MODE_PRIVATE);
    web=new WebView(this); web.setBackgroundColor(0xff0b1323); web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.getSettings().setAllowContentAccess(false);
    web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new Bridge(),"Android"); setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
    manager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
    stepSensor=manager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
    if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION},42);
  }
  @Override protected void onResume(){super.onResume();startSensor();}
  @Override protected void onPause(){if(manager!=null)manager.unregisterListener(this);super.onPause();}
  private void startSensor(){if(stepSensor!=null && (Build.VERSION.SDK_INT<29 || checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)==PackageManager.PERMISSION_GRANTED)) manager.registerListener(this,stepSensor,SensorManager.SENSOR_DELAY_NORMAL);}
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==42)startSensor();}
  @Override public void onAccuracyChanged(Sensor s,int a){}
  @Override public void onSensorChanged(SensorEvent e){
    if(e.sensor.getType()!=Sensor.TYPE_STEP_COUNTER)return;
    float raw=e.values[0]; String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    String bootKey="last_raw",dayKey="day",totalKey="total",baseKey="base";
    String prevDay=prefs.getString(dayKey,"");float previous=prefs.getFloat(bootKey,-1f);
    int total=prefs.getInt(totalKey,0);
    if(!today.equals(prevDay)){total=0; prefs.edit().putString(dayKey,today).putInt(totalKey,0).apply();}
    if(previous>=0 && raw>=previous && today.equals(prevDay)){total+=(int)(raw-previous);} // Handles resets/reboots conservatively
    prefs.edit().putFloat(bootKey,raw).putInt(totalKey,total).apply();
    final int n=total;web.post(()->web.evaluateJavascript("window.receiveSteps && window.receiveSteps("+n+")",null));
  }
  public class Bridge {
    @JavascriptInterface public void saveText(String filename,String content,String mime){
      if(content==null || content.length()>12000000)return;
      pendingText=content;
      runOnUiThread(()->{Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime!=null && mime.contains("csv")?"text/csv":"application/json");
        intent.putExtra(Intent.EXTRA_TITLE,filename);startActivityForResult(intent,51);});
    }
    @JavascriptInterface public int getSteps(){return prefs.getInt("total",0);}
    @JavascriptInterface public boolean hasStepSensor(){return stepSensor!=null;}
    @JavascriptInterface public void requestSteps(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=29 && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION},42);else startSensor();});}
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==51 && resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingText!=null){
      try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){
        if(stream!=null)stream.write(pendingText.getBytes(StandardCharsets.UTF_8));
      }catch(Exception e){android.widget.Toast.makeText(this,"Error al guardar: "+e.getMessage(),android.widget.Toast.LENGTH_LONG).show();}
    }
    pendingText=null;
  }
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
