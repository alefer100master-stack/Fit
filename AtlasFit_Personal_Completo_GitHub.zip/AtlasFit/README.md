# AtlasFit Personal — Android

Aplicación personal de entrenamiento, alimentación y medidas corporales. Funciona sin cuentas ni servidores, con interfaz en español y datos locales. Proyecto Android Java + WebView HTML/CSS/JS, compilable en GitHub Actions.

## Generar el APK

1. Descomprime `AtlasFit_Personal_Completo_GitHub.zip`.
2. Crea un repositorio **privado** de GitHub y sube **el contenido** de la carpeta `AtlasFit` a la raíz, incluyendo `.github/workflows/android-apk.yml` (GitHub permite subir archivos, o puedes usar git).
3. Abre **Actions → Compilar APK Android → Run workflow**. También se ejecuta al hacer push a `main` o `master`.
4. Descarga el artefacto **AtlasFit-APK** de la ejecución exitosa. Extrae `app-debug.apk` e instálalo en Android.
5. Haz una primera copia JSON desde Ajustes y guárdala en una carpeta segura.

**Estado de verificación:** JavaScript verificado sintácticamente con Node 22; estructura del proyecto y flujo revisados. No se ha ejecutado Gradle ni instalado el APK en un teléfono desde este entorno. Un build exitoso de GitHub es la primera verificación de compilación. El APK debug no requiere publicación comercial.

## Auditoría de funcionalidades

| Solicitud | Implementación | Precisión / límite |
|---|---|---|
| Entrenar cuando vaya al gimnasio, no por calendario | Sesiones manuales Fuerza A, Fuerza B y Cardio, con inicio y fin | El usuario elige sesión; no obliga días fijos |
| Biblioteca visual de máquinas | 14 ejercicios con esquemas SVG originales, técnica, advertencias y búsqueda | Esquemas por grupo muscular, **no** fotografías verificadas ni animaciones biomecánicas |
| Registrar pesos y estatura | Perfil y mediciones independientes | Valores manuales |
| Medidas antes y después | Peso, cintura, abdomen al ombligo y cadera, con fecha | Para comparación válida usa el mismo punto anatómico cada vez |
| Series y cargas reales | Registrar series individuales (repeticiones y kg), RPE y notas | El peso de máquina puede no ser comparable entre marcas |
| Estadísticas | Sesiones, minutos, ejercicios, series, volumen externo, cambios y tendencias | Estadística descriptiva, no prueba causal ni medición directa de grasa visceral |
| Dieta bogotana | Alimentos habituales, ejemplos de platos y registro de porciones con proteínas/kcal estimadas | Los valores varían con preparación, peso y marca; no es un plan calórico clínicamente personalizado |
| Complementos actuales | Omega-3, zinc, curcumina, ashwagandha, creatina como opción | Ninguno es un quemador demostrado de grasa abdominal |
| Pasos Samsung S24 Ultra | Sensor Android TYPE_STEP_COUNTER y permiso de actividad | Solo lecturas observadas mientras app activa; **no** Samsung Health, Health Connect ni pasos históricos |
| Respaldo de datos | JSON, CSV y restauración JSON | Almacenamiento local; desinstalar puede borrar datos; exportar frecuentemente |
| APK mediante GitHub | GitHub Actions con Gradle y SDK Android | Se debe compilar en GitHub; no se incluye APK precompilado |

## Uso recomendado

- **Al llegar al gimnasio:** elige una rutina y registra cargas/series/repeticiones; añade esfuerzo y notas antes de finalizar.
- **Peso:** idealmente varias mañanas por semana, en condiciones similares; evalúa la tendencia y no solo una lectura.
- **Cintura y abdomen:** cada 2–4 semanas es suficiente; no hace falta medirlos diariamente. Mantén los dos puntos de medida separados.
- **Nutrición:** registra las porciones consumidas. La proteína orientativa de 1,2–1,6 g/kg/día es un punto de partida, no una prescripción individual.
- **Actividad:** la meta general OMS es 150–300 min/semana de ejercicio aeróbico moderado y fuerza al menos dos días/semana; progresa según tolerancia.

## Seguridad y límites científicos

No existe reducción localizada fiable de grasa por hacer abdominales. El cambio de cintura depende de pérdida global de grasa, actividad, alimentación y variación individual. Una disminución de cintura es útil, pero **no demuestra por sí sola** una disminución medida de grasa visceral. La app no estima porcentaje de grasa ni gasto calórico desde pasos. No ofrece diagnóstico médico.

Si hay dolor lumbar persistente, dolor irradiado o debilidad, evita el movimiento que lo desencadena y solicita valoración. Las cargas y objetivos de dieta se deben individualizar si existen problemas de salud o medicación relevante.

## Privacidad

No hay servidor ni analítica remota. La base de datos se conserva en almacenamiento local WebView. Los archivos JSON contienen información corporal sensible: guarda copias con acceso restringido. Android permite elegir destino para las exportaciones JSON/CSV.

## Referencias generales para revisar

- WHO (2020), *Guidelines on physical activity and sedentary behaviour*: https://www.who.int/publications/i/item/9789240015128
- ACSM, *Progression Models in Resistance Training for Healthy Adults*, Medicine & Science in Sports & Exercise (2009), doi:10.1249/MSS.0b013e3181915670
- Morton et al. (2018), protein supplementation and resistance training meta-analysis, British Journal of Sports Medicine, doi:10.1136/bjsports-2017-097608

